package mainGame;

public class Collectable {
	static int level = 1;
	
	public static int[][] CreateCollectables() {
		int posX, posY;
		
		int[][] collectables = new int[level+4][2];
		 for(int i = 0; i < collectables.length; i++ ) {
				 posX = (int) (Math.random()*20);
				 posY = (int) (Math.random()*20);
				 while(posX == 0 && posX == posY) {
					 posY = (int) (Math.random()*20);
				 }
				 collectables[i][0] = posX;
				 collectables[i][1] = posY;
				 System.out.println("X: "+collectables[i][0]+" Y: "+collectables[i][1]);
		 }
		 return collectables;
	}
}

